# Field Mapping Matrix — MyPetLink

**Audit status: PARTIAL.** This matrix is built from static code inspection of the current repository, plus the automated tests that exist and the local-live round-trip performed for F-01 (Favourite Food/Toy). Rows that are only code-traced are **not** a claim of runtime persistence. Production was not tested.

**Evidence levels** (only these values are used): `CODE-TRACED` · `AUTOMATED-TEST` · `LOCAL-LIVE` · `PRODUCTION-LIVE` · `NOT-TESTED` · `FAILED`.
**Status values:** `Verified` · `Partially verified` · `Not verified` · `Missing implementation` · `Confirmed defect` · `Resolved defect` · `Not applicable`.

Convention used here: a field whose full path (frontend → request → DTO → entity → column → response) is coherent in source but has **not** been executed at runtime is **Partially verified** with evidence `CODE-TRACED`. "Missing implementation" = requested/expected but no field exists in UI, DTO, entity, or column. Reload/Public/Safety cells: ✅ present in that surface · ⚠️ conditional on a privacy flag · ➖ not applicable.

The literal "Module" and "Page/Route" columns from the request are represented as the section headings below; every other required column is present per row.

---

## Owner Account & Profile — Page: `/settings` (`SettingsPanel`) → `PUT /api/v1/owner/profile`

| Field | Editable | Frontend state | Validation | Request property | Request/Response DTO | Entity → DB column | Reload | Public | Safety | Privacy control | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Owner display name | Yes | `ownerDisplayName` | max ~200 | `DisplayName` | `UpdateOwnerProfileRequest`/`OwnerProfileResponse` | `OwnerProfiles.OwnerDisplayName` | ✅ | ⚠️ | ⚠️ | `showOwnerName` (per pet) | CODE-TRACED | Partially verified | Owner-profile save/reload not live-tested |
| Email | No (API mode) | `email` (`disabled={apiMode}`) | email type | — (not in update DTO) | `OwnerProfileResponse.Email` | `Users.Email` | ✅ read-only | ➖ | ➖ | — | CODE-TRACED | Not applicable | Read-only from auth; edits impossible in production |
| Phone number | Yes | `phoneNumber` | E.164 (`PhoneNumberInput`) | `PhoneE164` | update/response | `Users.PhoneE164` | ✅ | ❌ | ⚠️ | `showPhone` | CODE-TRACED | Partially verified | — |
| WhatsApp number | Yes | `whatsappNumber` | E.164 | `WhatsappE164` | update/response | `Users.WhatsappE164` | ✅ | ❌ | ⚠️ | `showWhatsapp` | CODE-TRACED | Partially verified | — |
| Country code | Yes | part of `PhoneNumberInput` | — | (embedded in E.164) | — | (embedded) | ✅ | ➖ | ➖ | — | CODE-TRACED | Not applicable | Not a standalone persisted field |
| Default general area | Yes | `defaultGeneralArea` | max ~200 | `DefaultGeneralArea` | update/response | `OwnerProfiles.DefaultGeneralArea` | ✅ | ⚠️ | ⚠️ | `showGeneralArea` | CODE-TRACED | Partially verified | — |
| Privacy defaults (11 flags) | Yes | checkboxes | bool | `PrivacyDefaults` | `PetVisibilityRequest` | `OwnerProfiles.PrivacyDefaultsJson` | ✅ | ➖ | ➖ | — | CODE-TRACED | Partially verified | Applied as new-pet defaults |
| Notification/reminder prefs | Yes | reminder toggles | — | `NotificationPreferences` (JSON) | update/response | `OwnerProfiles.NotificationPreferencesJson` | ✅ | ➖ | ➖ | — | CODE-TRACED | Partially verified | JSON blob |
| Owner profile image | — | initial-letter avatar only | — | — | — | — | ➖ | ➖ | ➖ | — | NOT-TESTED | Missing implementation | No upload field/column; avatar is a generated initial |
| Owner postal address | — | — | — | — | — | — | ➖ | ➖ | ➖ | — | NOT-TESTED | Missing implementation | By design only "general area" exists |
| Owner-level emergency contact | — | — | — | — | — | — | ➖ | ➖ | ➖ | — | NOT-TESTED | Missing implementation | Emergency contact exists per-pet only |

---

## Pet Basic Information — Page: `/pets/:id/edit` (`PetProfileForm`) → `POST/PUT /api/v1/pets{/:id}`

| Field | Editable | Frontend state | Validation | Request property | Request/Response DTO | Entity → DB column | Reload | Public | Safety | Privacy | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Name | Yes | `name` | required, max 60/120 | `Name` | Create/Update/Detail | `Pets.Name` | ✅ | ✅ | ✅ | no | CODE-TRACED | Partially verified | — |
| Species | Yes | `species` | required, max 80 | `Species` | " | `Pets.Species` | ✅ | ✅ | ✅ | no | CODE-TRACED | Partially verified | — |
| Custom species | Yes | `customSpecies` | max 120 | `CustomSpecies` | " | `Pets.CustomSpecies` | ✅ | ✅ | ➖ | no | CODE-TRACED | Partially verified | — |
| Breed | Yes | `breed` | max 160 | `Breed` | " | `Pets.Breed` | ✅ | ✅ | ➖ | no | CODE-TRACED | Partially verified | — |
| Gender | Yes | `gender` | max 80 | `Gender` | " | `Pets.Gender` | ✅ | ✅ | ➖ | no | CODE-TRACED | Partially verified | — |
| Colour | Yes | `color` | max 120 | `Color` | " | `Pets.Color` | ✅ | ✅ | ➖ | no | CODE-TRACED | Partially verified | — |
| Birthday | Yes | `birthdayDate` | date, not future, min year | `Birthday`+`AgeInformationMode` | " | `Pets.Birthday` | ✅ (age) | ✅ (age) | ✅ (age) | no | CODE-TRACED, AUTOMATED-TEST | Partially verified | Age tests exist; age derived not stored |
| Estimated birth year | Yes | `estimatedBirthYear` | year range | `EstimatedBirthYear`+mode | " | `Pets.EstimatedBirthYear` | ✅ (age) | ✅ (age) | ✅ (age) | no | CODE-TRACED, AUTOMATED-TEST | Partially verified | — |
| Age information mode | Yes | `ageInformationMode` | enum | `AgeInformationMode` | " | (drives Birthday/Est.) | ✅ | ➖ | ➖ | no | CODE-TRACED, AUTOMATED-TEST | Partially verified | Exact vs Estimated vs Unknown |
| Weight | — | — | — | — | — | — | ➖ | ➖ | ➖ | — | NOT-TESTED | Missing implementation | No field/column |
| Microchip / identification | — | — | — | — | — | — | ➖ | ➖ | ➖ | — | NOT-TESTED | Missing implementation | No field/column |
| Biography / About | Yes | `bio` | max 320/2000 | `Bio` | " | `Pets.Bio` | ✅ | ✅ | ➖ | no | CODE-TRACED | Partially verified | — |
| Favourite food | Yes | `favoriteFood` | max 80 | `FavoriteFood` | Create/Update/Detail + Public | `Pet.FavoriteFood` / `Pets.FavoriteFood` (nvarchar NULL) | ✅ | ✅ (if set) | ➖ | no | CODE-TRACED, AUTOMATED-TEST, LOCAL-LIVE | **Resolved defect** | F-01; blank→NULL; browser Edit-form pass still LIVE-TEST |
| Favourite toy | Yes | `favoriteToy` | max 80 | `FavoriteToy` | Create/Update/Detail + Public | `Pet.FavoriteToy` / `Pets.FavoriteToy` | ✅ | ✅ (if set) | ➖ | no | CODE-TRACED, AUTOMATED-TEST, LOCAL-LIVE | **Resolved defect** | F-01 |
| Personality tags | Yes | `personalityTags` | max 160 str; ≤12 tags | `PersonalityTags[]` | " | `Pets.PersonalityTagsJson` | ✅ | ✅ | ➖ | no | CODE-TRACED, AUTOMATED-TEST | Partially verified | Backend tag tests exist |
| Adoption day | Yes | `adoptionDate` | date | `AdoptionDay` | " | `Pets.AdoptionDay` | ✅ | ⚠️ timeline | ➖ | `showAdoptionDayOnTimeline` | CODE-TRACED | Partially verified | — |

---

## Pet Media & Theme — `PetProfileForm` + media upload (`POST /api/v1/media/uploads` → PUT → `/complete`)

| Field | Editable | Frontend | Validation | Request | Entity → DB | Reload | Public | Safety | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Profile image | Yes | `ImageUploadField` | image type/size | category `PetProfilePhoto` | `Pets.ProfileMediaFileId` → `MediaFiles` | ✅ | ✅ | ✅ | CODE-TRACED | Partially verified | Media lifecycle live-test outstanding |
| Cover image | Yes | `ImageUploadField` | image type/size | category `PetCoverPhoto` | `Pets.CoverMediaFileId` → `MediaFiles` | ✅ | ✅ | ⚠️ | CODE-TRACED | Partially verified | — |
| Cover position X | Yes | crop/reposition | 0–100 | `CoverPositionX` | `Pets.CoverPositionX` | ✅ | ✅ | ➖ | CODE-TRACED, AUTOMATED-TEST | Partially verified | Test `AddPetCoverFocalPosition` migration |
| Cover position Y | Yes | crop/reposition | 0–100 | `CoverPositionY` | `Pets.CoverPositionY` | ✅ | ✅ | ➖ | CODE-TRACED, AUTOMATED-TEST | Partially verified | — |
| Profile theme | Yes | `profileTheme` | max 64 / enum-ish | `ProfileTheme` | `Pets.ProfileTheme` | ✅ | ✅ | ➖ | CODE-TRACED | Partially verified | — |
| Media public/private visibility | Auto | by category | — | `MediaFiles.IsPublic` | `MediaFiles.IsPublic`/`BucketName` | ✅ | ✅ | ✅ | CODE-TRACED | Partially verified | Public bucket for profile/cover/moment |

---

## Contact & Safety — `PetProfileForm` (Contact & Safety tab)

| Field | Editable | Request property | Entity → DB | Public | Safety | Privacy control | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|---|
| Use owner defaults | Yes | `Contact.UseOwnerDefaults` | `PetContacts.UseOwnerDefaults` | ➖ | ➖ | — | CODE-TRACED | Partially verified | — |
| Pet owner display name | Yes | `Contact.OwnerDisplayName` | `PetContacts.OwnerDisplayName` | ⚠️ | ⚠️ | `showOwnerName` | CODE-TRACED | Partially verified | — |
| Pet phone | Yes | `Contact.PhoneE164` | `PetContacts.PhoneE164` | ❌ never | ⚠️ | `showPhone` | CODE-TRACED | Partially verified | Absent from public DTO |
| Pet WhatsApp | Yes | `Contact.WhatsappE164` | `PetContacts.WhatsappE164` | ❌ | ⚠️ | `showWhatsapp` | CODE-TRACED | Partially verified | — |
| Pet emergency contact | Yes | `Contact.EmergencyContactE164` | `PetContacts.EmergencyContactE164` | ❌ | ⚠️ | `showPhone` (gates it) | CODE-TRACED | Partially verified | See product-decision D in issues |
| Pet general area override | Yes | `Contact.GeneralAreaOverride` | `PetContacts.GeneralAreaOverride` | ⚠️ | ⚠️ | `showGeneralArea` | CODE-TRACED | Partially verified | — |
| Safety note | Yes | `SafetyNote` | `Pets.SafetyNote` | ➖ | ✅ always | — | CODE-TRACED | Partially verified | Product decision: always public on safety page |
| Emergency note | Yes | `EmergencyNote` | `Pets.EmergencyNote` | ➖ | ⚠️ | `showEmergencyNote` | CODE-TRACED | Partially verified | Also reused as "medical warning" text |
| Medical warning (dedicated) | — | — | — | ➖ | ➖ | — | NOT-TESTED | Missing implementation | No dedicated field; emergency note used |

### Visibility flags (each persisted to `PetPublicProfiles`/`PetSafetySettings`)
`ShowOwnerName, ShowGeneralArea, ShowPhone, ShowWhatsapp, ShowEmergencyNote, ShowCareBadges, ShowMoments, ShowTimeline, ShowBirthdayOnTimeline, ShowAdoptionDayOnTimeline, ShowHealthSummary` — **11 fields**, each editable checkbox → `PetVisibilityRequest`→ enforced server-side in `PublicProfileService`/`QrSafetyService`. Evidence `CODE-TRACED`; Status **Partially verified** (privacy combinations not live-tested).

### Lost Mode (Manage Lost Mode → `PUT /api/v1/pets/:id`)
`LostModeEnabled, LostMessage, LostLastSeenArea, LostLastSeenDateTime, LostRewardNote, LostExtraContactInstruction` — **6 fields** → `Pets.Lost*`. Public: banner only; Safety: shown when lost. Evidence `CODE-TRACED`; Status **Partially verified**.

### Lifecycle & Memorial (dedicated endpoints)
`LifecycleStatus` (`/archive`,`/restore-active`), `MemorialPassedAwayDate`,`MemorialMessage`,`ShowMemorialOnPublicProfile` (`/mark-memorial`) — **4 fields**. Evidence `CODE-TRACED`; Status **Partially verified**.

---

## Care Records — `/pets/:id/records` (`RecordsManager`) → `/api/v1/pets/:id/records`

| Field | Editable | Request property | Entity → DB | Public | Privacy | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|
| Type (Vaccine/Deworming/Grooming/VetVisit/Medication/Allergy/Surgery/LabTest/Other) | Yes | `Type` (enum) | `CareRecords.Type` | ⚠️ badge | `showCareBadges` | CODE-TRACED | Partially verified | Vaccination/Deworming/Grooming/VetVisit/Medication/Allergy are **enum values**, not separate fields |
| Title | Yes | `Title` (req, max 160) | `CareRecords.Title` | ⚠️ details | `showHealthSummary` | CODE-TRACED | Partially verified | — |
| Date | Yes | `Date` | `CareRecords.RecordDate` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Due date | Yes | `DueDate` | `CareRecords.DueDate` | ⚠️ | — | CODE-TRACED | Partially verified | Drives derived status |
| Provider | Yes | `Provider` (max 160) | `CareRecords.Provider` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Notes | Yes | `Notes` (max 2000) | `CareRecords.Notes` | ⚠️ details only | `showHealthSummary` + `PublicDetails` | CODE-TRACED | Partially verified | — |
| Public visibility (Private/PublicBadgeOnly/PublicDetails) | Yes | `PublicVisibility` (enum) | `CareRecords.PublicVisibility` | ⚠️ | itself | CODE-TRACED | Partially verified | — |
| Attachments | Yes | `MediaFileIds[]` | `MediaFileLinks` (CareRecord) | ➖ | — | CODE-TRACED | Partially verified | Media lifecycle live-test outstanding |
| Health conditions | — | — | — | ➖ | — | NOT-TESTED | Missing implementation | Not a field |
| Feeding instructions | — | — | — | ➖ | — | NOT-TESTED | Missing implementation | Not a field |
| Behaviour notes | — | — | — | ➖ | — | NOT-TESTED | Missing implementation | Not a field |

---

## Moments / Memories — `/pets/:id/moments` (`PetMomentForm`) → `/api/v1/pets/:id/memories`

| Field | Editable | Request property | Entity → DB | Public | Privacy | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|---|
| Title | Yes | `Title` (req, max 160) | `PetMemories.Title` | ⚠️ | `showMoments` + visibility | CODE-TRACED | Partially verified | — |
| Date | Yes | `Date` | `PetMemories.MomentDate` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Type | Yes | `Type` (req, max 80) | `PetMemories.Type` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Caption | Yes | `Caption` (max 2000) | `PetMemories.Caption` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Visibility (Public/Private/FamilyOnly) | Yes | `Visibility` (enum) | `PetMemories.Visibility` | ⚠️ | itself + `showMoments` | CODE-TRACED | Partially verified | Only `Public` shows publicly |
| Show on public profile | Yes | `ShowOnPublicProfile` | `PetMemories.ShowOnPublicProfile` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Show in life timeline | Yes | `ShowInLifeTimeline` | `PetMemories.ShowInLifeTimeline` | ⚠️ | `showTimeline` | CODE-TRACED | Partially verified | — |
| Timeline note | Yes | `TimelineNote` (max 500) | `PetMemories.TimelineNote` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Photos / Videos (media) | Yes | `MediaFileIds[]` | `MediaFileLinks` (PetMemory) | ⚠️ | — | CODE-TRACED | Partially verified | Video duration/poster display = live-test/gap |
| Cover media | Yes | (auto/first) | `PetMemories.CoverMediaFileId` | ⚠️ | — | CODE-TRACED | Partially verified | — |
| Media ordering | Yes | `SortOrder` on link | `MediaFileLinks.SortOrder` | ⚠️ | — | CODE-TRACED | Partially verified | — |

---

## Smart Tags — owner tag pages + Admin; `TagScanService` / admin tag endpoints

| Field | Editable | Source | Entity → DB | Safety/Scan surface | Evidence | Status | Notes |
|---|---|---|---|---|---|---|---|
| Tag code | No (generated) | admin/inventory | `SmartTags.TagCode` | `/t/{tagCode}` | CODE-TRACED | Partially verified | — |
| Tag assignment (pet) | Admin | assign/change/replace | `SmartTags.PetId` | resolves pet | CODE-TRACED | Partially verified | Reassignment cache behaviour = gap |
| Tag status | Admin | status actions | `SmartTags.Status` | drives state | CODE-TRACED | Partially verified | Unclaimed/Pending/Active/Lost/Disabled/Replaced/Archived |
| Tag variant | Admin/order | order/inventory | `SmartTags`/batch | — | CODE-TRACED | Partially verified | Lightweight/Standard |
| QR status | Derived | from status | (derived) | "QR Active" | CODE-TRACED | Partially verified | Must reflect real status live |
| NFC status | Derived | `HasNfc` | `SmartTags.HasNfc` | "NFC Ready" | CODE-TRACED | Partially verified | Must not show false NFC for QR-only variant (live) |
| Lost Mode relationship | — | pet Lost Mode | `Pets.LostModeEnabled` | banner | CODE-TRACED | Partially verified | — |
| Archive status | Admin | archive/restore | `SmartTags.ArchivedAt` | inactive card | CODE-TRACED | Partially verified | — |
| Found-location reporting | Public | `SubmitScanLocationConsentRequest` | `TagScans` (lat/long/consent) | found flow | CODE-TRACED, NOT-TESTED | Partially verified | Runtime found-flow not tested |
| Scan history | Auto | `TagScanService.RecordScanAsync` | `TagScans` | — | CODE-TRACED | Partially verified | — |

---

## Orders & Payments (displayed in Owner Portal `/orders`) — read-mostly

| Field | Editable | Source | Entity → DB | Evidence | Status | Notes |
|---|---|---|---|---|---|---|
| Order number | No | order | `TagOrders.OrderNumber` | CODE-TRACED | Partially verified | Display only |
| Order status | No | order | `TagOrders.Status` | CODE-TRACED | Partially verified | — |
| Payment status | No | order | `TagOrders.PaymentStatus` | CODE-TRACED | Partially verified | — |
| Payment proof (upload) | Yes | media upload | `PaymentProofs` + `MediaFiles` | CODE-TRACED | Partially verified | Manual review phase; live-test outstanding |

---

## Field count (for README metrics)
- **Owner:** 11 rows (8 editable/persisted-path incl. 2 Not-applicable + 3 Missing).
- **Pet basic:** 16 rows (14 present + 2 Missing).
- **Media & theme:** 6 rows.
- **Contact & safety:** 9 rows + 11 visibility + 6 Lost Mode + 4 lifecycle/memorial = 30.
- **Care records:** 11 rows (8 present + 3 Missing).
- **Moments:** 11 rows.
- **Smart tags:** 10 rows.
- **Orders:** 4 rows.

**Total field rows identified: 99.** See `README.md` for the derived verification-level counts.
